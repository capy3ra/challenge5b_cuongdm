<?php $__env->startSection('content'); ?>
    <div class="panel-heading">
        <br/>
        <h1 style="color:green;text-align:center;">Edit information</h1>
        <br/>
    </div>
    <div class="panel-body">
        <form method="post" action="<?php echo e(route('userList.update', $user->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <div class="mb-3">
                <?php if($user->avatar): ?>
                    <img src="<?php echo e(url("storage/".$user->avatar)); ?>" alt="avatar" width="200px" height="200px" style="border-radius:50%; margin: auto; display: block;">
                <?php else: ?>
                    <img src="https://thumbs.dreamstime.com/b/default-avatar-profile-icon-vector-social-media-user-portrait-176256935.jpg" alt="avatar" width="200px" height="200px" style="border-radius:50%; margin: auto; display: block;">
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label for="usr" class="form-label">User name: </label>
                <input type="text" class="form-control" name="urs" require="true" value="<?php echo e($user->username); ?>" disabled="disabled">
            </div>
            <div class="mb-3">
                <label for="full-name" class="form-label">Full name: </label>
                <input type="text" class="form-control" name="full-name" require="true" value="<?php echo e($user->full_name); ?>" disabled="disabled">
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email address: </label>
                <input type="email" class="form-control" name="email" require="true" value="<?php echo e($user->email); ?>">
            </div>
            <div class="mb-3">
                <label for="phone-number" class="form-label">Phone number: </label>
                <input type="tel" class="form-control" name="phone-number" require="true" value="<?php echo e($user->phone_number); ?>">
            </div>
            <div class="mb-3">
                <input class="btn btn-success" type="submit" value="Update">
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\challenge5b_cuongdm\resources\views/user/edit.blade.php ENDPATH**/ ?>