<?php $__env->startSection('content'); ?>
    <div class="panel-heading">
    <br/>
        <h1 style="color:green;text-align:center;">Assignment Management</h1>
    <br/>
    </div>
    <?php if(auth()->user()->isTeacher ): ?>
        <td><a href="<?php echo e(route('classroom.create')); ?>"><button class="btn btn-success">Add</button></a></td>
    <?php endif; ?>
    <div class="panel-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-3" style="border-radius: 5px;">
            <h5 class="display-3">
            <small class="text-muted"><?php echo e($assignment->title); ?></small>
            </h5>
            <label for="des" class="form-label">Description: </label>
            <br/>
            <textarea rows="5" cols="75" id="des" disabled><?php echo e($assignment->description); ?></textarea>
            <br/>
            
            <td><a href="<?php echo e(route('classroom.assignment.download', $assignment->id)); ?>"><button class="btn btn-warning">Download</button></a></td>
            <?php if(auth()->user()->isTeacher ): ?>
                <td><a href="<?php echo e(route('classroom.assignment.detail', $assignment->id)); ?>"><button class="btn btn-primary">Detail</button></a></td>
            <?php endif; ?>
            <?php if(!auth()->user()->isTeacher ): ?>
                <td><a href="<?php echo e(route('classroom.assignment.submit', $assignment->id)); ?>"><button class="btn btn-success">Submit</button></a></td>
            <?php endif; ?>
            <hr/>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\challenge5b_cuongdm\resources\views/assignment/index.blade.php ENDPATH**/ ?>