<?php $__env->startSection('content'); ?>
    <div class="panel-heading">
    </div>
    <?php if($success): ?>
        <div class="alert alert-success"><?php echo e($success); ?></div>
    <?php endif; ?>
    <div class="panel-body md3" style="padding-top: 120px;">
        <pre>
            <?php echo e($indicate); ?>

        </pre>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\challenge5b_cuongdm\resources\views/challenge/show.blade.php ENDPATH**/ ?>