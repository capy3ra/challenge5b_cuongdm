<?php $__env->startSection('content'); ?>
    <div class="panel-heading">
        <br/>
        <h1 style="color:green;text-align:center;">Home</h1>
        <br/>
    </div>
    <div class="panel-body">
        <div class="md-3">
            <li class="list-group-item"><a href="<?php echo e(route('userList.index')); ?>" style="text-decoration: none; color: black;" onMouseOver="this.style.color='green'" onMouseOut="this.style.color='black'">User list</a></li>
        </div>
        <div class="md-3">
            <li class="list-group-item"><a href="<?php echo e(route('classroom.index')); ?>" style="text-decoration: none; color: black;" onMouseOver="this.style.color='green'" onMouseOut="this.style.color='black'">Assignment</a></li>
        </div>
        <div class="md-3">
            <li class="list-group-item"><a href="<?php echo e(route('challenge.index')); ?>" style="text-decoration: none; color: black;" onMouseOver="this.style.color='green'" onMouseOut="this.style.color='black'">Challenge</a></li>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\challenge5b_cuongdm\resources\views/index.blade.php ENDPATH**/ ?>