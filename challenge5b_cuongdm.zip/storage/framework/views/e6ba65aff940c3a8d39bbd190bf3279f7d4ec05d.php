<?php $__env->startSection('content'); ?>
    <div class="panel-heading">
        <br/>
        <h1 style="color:green;text-align:center;">Information of <?php echo e($curuser->full_name); ?></h1>
        <br/>
    </div>
<form method="post">
    <?php if($curuser->avatar): ?>
        <img src="<?php echo e(url("storage/".$curuser->avatar)); ?>" alt="avatar" width="200px" height="200px" style="border-radius:50%; margin: auto; display: block;">
    <?php else: ?>
        <img src="https://thumbs.dreamstime.com/b/default-avatar-profile-icon-vector-social-media-user-portrait-176256935.jpg" alt="avatar" width="200px" height="200px" style="border-radius:50%; margin: auto; display: block;">
    <?php endif; ?>
    <div class="mb-3">
        <label for="usr" class="form-label">User name: </label>
        <input type="text" class="form-control" name="urs" require="true" value="<?php echo e($curuser->username); ?>" disabled="disabled">
    </div>

    <div class="mb-3">
        <label for="full-name" class="form-label">Full name: </label>
        <input type="text" class="form-control" name="full-name" require="true" value="<?php echo e($curuser->full_name); ?>" disabled="disabled">
    </div>
    <div class="mb-3">
        <label for="email" class="form-label">Email address: </label>
        <input type="email" class="form-control" name="email" require="true" value="<?php echo e($curuser->email); ?>" disabled="disabled">
    </div>
    <div class="mb-3">
        <label for="phone-number" class="form-label">Phone number: </label>
        <input type="tel" class="form-control" name="phone-number" require="true" value="<?php echo e($curuser->phone_number); ?>" disabled="disabled">
    </div>
    <div class="mb-3">
        <label for="role" class="form-label">Role: </label>
        <input type="text" class="form-control" name="isTeacher" require="true" value="<?php if($curuser->isTeacher): ?> <?php echo e("Teacher"); ?> <?php else: ?> <?php echo e("Student"); ?> <?php endif; ?>" disabled="disabled">
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\challenge5b_cuongdm\resources\views/user/detail.blade.php ENDPATH**/ ?>