
<?php $__env->startSection('content'); ?>
    <div class="panel-heading">
    <br/>
        <h1 style="color:green;text-align:center;">Submission Management</h1>
    <br/>
    </div>
    <div class="panel-body">
        <?php if(session('success')): ?>
            <?php echo e(session('success')); ?>

        <?php endif; ?>
        
        <?php $__currentLoopData = $submissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-3" style="border-radius: 5px;">
            <h6>From <strong><?php echo e($submission->user->full_name); ?></strong></h6>
            <h5 class="display-5"><?php echo e($submission->title); ?>

            <small class="text-muted"><?php echo e($submission->updated_at); ?></small>
            </h5>
            
            <label for="des" class="form-label">Description: </label>
            <br/>
            <textarea rows="5" cols="75" id="des" disabled><?php echo e($submission->description); ?></textarea>
            <br/>
            <td><a href="<?php echo e(route('classroom.submission.download', $submission->id)); ?>"><button class="btn btn-warning">Download</button></a></td>
            <hr/>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\challenge5b_cuongdm\resources\views/assignment/detail.blade.php ENDPATH**/ ?>