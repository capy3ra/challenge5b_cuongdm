
<?php $__env->startSection('content'); ?>
    <div class="panel-heading">
        <br/>
        <h1 style="color:green;text-align:center;">Challenger</h1>
        <br/>
    </div>
    <?php if(auth()->user()->isTeacher): ?>
        <a href="<?php echo e(route('challenge.create')); ?>"><button class="btn btn-success">Create question</button></a>
    <?php endif; ?>
    <div class="panel-body">
        <?php $__currentLoopData = $challenges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $challenge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-3" style="border-radius: 5px;">
            <h5 class="display-4"><?php echo e($challenge->title); ?>

            </h5>
            <label for="des" class="form-label">HINT: </label>
            <br/>
            <textarea rows="5" cols="75" id="des" disabled><?php echo e($challenge->hint); ?></textarea>
            <br/>
            <?php if(!auth()->user()->isTeacher): ?>
            <a href="<?php echo e(route('challenge.answer', $challenge->id)); ?>"><button class="btn btn-success">Answer</button></a>
            <?php endif; ?>
            <hr/>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\challenge5b_cuongdm\resources\views/challenge/index.blade.php ENDPATH**/ ?>