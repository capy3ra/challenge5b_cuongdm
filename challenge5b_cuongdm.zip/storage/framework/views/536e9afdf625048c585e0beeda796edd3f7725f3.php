<?php $__env->startSection('content'); ?>
    <div class="panel-heading">
        <br/>
        <h1 style="color:green;text-align:center;">Information of student and teacher</h1>
        <br/>
    </div>
    <div class="panel-body">
        <a href="<?php echo e(route('userList.create')); ?>"><button class="btn btn-primary">Add user</button></a>
        <br/>
        <br/>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
            <tr>
                <th>ID</th>
                <th>Full name</th>
                <th>Username</th>
                <th>Email</th>
                <th>Phone Number</th>
                <th>Role</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->full_name); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone_number); ?></td>
                    
                    <?php if($user->isTeacher === 1): ?>
                        <td>Teacher</td>

                    <?php else: ?>
                        <td>Student</td>
                    <?php endif; ?>
                    <?php if(auth()->user()->isTeacher == 1): ?>
                        <td><a href="<?php echo e(route('userList.edit', $user->id)); ?>"><button class="btn btn-warning">Edit</button></a></td>
                        <td><a href="<?php echo e(route('userList.detail', $user->id)); ?>"><button class="btn btn-primary">Detail</button></a></td>
                        <td><a href="<?php echo e(route('userList.delete', $user->id)); ?>"><button class="btn btn-danger">Delete</button></a></td>
                    <?php endif; ?>
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\challenge5b_cuongdm\resources\views/user/index.blade.php ENDPATH**/ ?>