<?php $__env->startSection('content'); ?>
    <div class="panel-heading">
        <br/>
        <h1 style="color:green;text-align:center;">Your information</h1>
        <br/>
    </div>
    <div class="panel-body">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <?php if(auth()->user()->avatar): ?>
                    <img src="<?php echo e(url("storage/".Auth::user()->avatar)); ?>" alt="avatar" width="200px" height="200px" style="border-radius:50%; margin: auto; display: block;">
                <?php else: ?>
                    <img src="https://thumbs.dreamstime.com/b/default-avatar-profile-icon-vector-social-media-user-portrait-176256935.jpg" alt="avatar" width="200px" height="200px" style="border-radius:50%; margin: auto; display: block;">
                <?php endif; ?>

            </div>
            <div class="mb-3">
                <label for="usr" class="form-label">User name: </label>
                <input type="text" class="form-control" name="urs" require="true" value="<?php echo e(auth()->user()->username); ?>" disabled="disabled">
            </div>
            <a href="<?php echo e(route('changePwd.index')); ?>" class="link-success">Change password</a>

            <div class="mb-3">
                <label for="full-name" class="form-label">Full name: </label>
                <input type="text" class="form-control" name="full-name" require="true" value="<?php echo e(auth()->user()->full_name); ?>" disabled="disabled">
            </div>
            <div class="mb-3">
                <label for="email" class="form-label">Email address: </label>
                <input type="email" class="form-control" name="email" require="true" value="<?php echo e(auth()->user()->email); ?>">
            </div>
            <div class="mb-3">
                <label for="phone-number" class="form-label">Phone number: </label>
                <input type="tel" class="form-control" name="phone-number" require="true" value="<?php echo e(auth()->user()->phone_number); ?>">
            </div>
            <div class="mb-3">
                <label for="avatar" class="form-label">Avatar: </label>
                <input type="file" class="form-control" name="avatar" require="true">
            </div>
            <div class="mb-3">
                <label for="role" class="form-label">Role: </label>
                <input type="text" class="form-control" name="isTeacher" require="true" value="<?php if(auth()->user()->isTeacher): ?> <?php echo e("Teacher"); ?> <?php else: ?> <?php echo e("Student"); ?> <?php endif; ?>" disabled="disabled">
            </div>
            <button type="submit" class="btn btn-success">Update</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\challenge5b_cuongdm\resources\views/user/profile.blade.php ENDPATH**/ ?>